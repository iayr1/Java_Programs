public class p13 {
    public static void main(String[] args) {
        int n = 4; //454545
        int m = n++ *  --n / n++ + --n;
        //      4   *  4   / 4   +  4 = 16/4+4 = 8
        int z = n * m + n++;
        //      4 * 8 + 4 = 36/37/36
        int x = z++ - --z * n / m;
        //      36  -  36 * 180 / 8 = 13.5 so it is converted to 14.     
        //Execution will  happen from left to right.
        //here bodmas rule is used as it is using operator precedence.
        System.out.println(n);
        System.out.println(m);
        System.out.println(z);
        System.out.println(x);
    }
}
