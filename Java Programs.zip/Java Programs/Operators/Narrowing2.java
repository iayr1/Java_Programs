package Operators;

public class Narrowing2 {

    public static void main(String[] args) {
                                      
        double d = 120.56;
        byte f1 = (byte)d;                                     
        System.out.println(f1);
        System.out.println(d);              
    }                      
}

    


