package Operators;

public class Add {
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 21;
        System.out.println(num1 + num2);
    }
}
