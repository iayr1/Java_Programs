package Operators;

public class Autowidening4 {
    public static void main(String[] args) {
        float f1 = 120.45f;
        double d = f1;
        System.out.println(f1);
        System.out.println(d);              
    }
}
