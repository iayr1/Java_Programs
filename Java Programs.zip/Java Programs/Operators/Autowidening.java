package Operators;

public class Autowidening {
    public static void main(String[] args) {
        char c = 'z';
        double d = c;
        System.out.println(c);
        System.out.println(d);              
    }
}
