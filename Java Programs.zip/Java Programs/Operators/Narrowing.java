package Operators;

public class Narrowing {

    public static void main(String[] args) {
                                      
        double d = 120.56;
        float f1 = (float)d;                                     
        System.out.println(f1);
        System.out.println(d);              
    }
}

    

