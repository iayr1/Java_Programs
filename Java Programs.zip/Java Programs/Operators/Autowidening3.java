package Operators;

public class Autowidening3 {
    public static void main(String[] args) {
        char c = 'z';
        double d = c;

        short s = 20;
        float f =(float)s; 
        System.out.println(c);
        System.out.println(d);
        System.out.println(s);
        System.out.println(f);              
    }
}

