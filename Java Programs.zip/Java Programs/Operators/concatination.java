package Operators;

public class concatination {
    public static void main(String[] args) {
            String s = "java";
    int n = 123;
    System.out.println(s + n); //java123
}
        
}

