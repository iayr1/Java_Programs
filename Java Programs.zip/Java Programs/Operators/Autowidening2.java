package Operators;

public class Autowidening2 {
    public static void main(String[] args) {
        char c = 'z';
        double d = (double)c; //using cast operator
        System.out.println(c);
        System.out.println(d);              
    }
}
