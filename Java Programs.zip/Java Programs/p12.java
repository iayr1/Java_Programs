public class p12 {
    public static void main(String[] args) {
        int a = 25;//26/25
        a = a++ + a;
        //   25 + 26 = 51/50/51/50/51
        int b = a + --a - a++  + a--;
        //      51 + 50 - 50   + 51   //102/101/102
        int c = a++ - --b + ++b -a;
        //      50 - 101 +  102 -51  //0
        int d = a + b - c;
        //      51 + 102 - 0  //153
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
    }
}
