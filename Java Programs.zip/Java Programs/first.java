class Main{
    public static void main(String a[]){
        // double num1 = 3.2;
        // double num2 = 6.7;
        float num1 = 5.3f;
        float num2 = 5.6f;
        System.out.println(num1 + num2);
    }
}
//int size is 4 bytes
//int long is 8 bytes
//int short is 2 bytes

//float takes 4 bytes
//double takes 8 bytes

// char takes 2 bytes
// Boolean --  True or False we use bool
