import java.util.Scanner;

public class swap {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the value of a: ");
        char a = scanner.next().charAt(0);

        System.out.print("Enter the value of b: ");
        char b = scanner.next().charAt(0);
        System.out.println("a = "+ a + ", b = "+ b);
        char t = a;
        a = b;
        b = t;
        System.out.println("a = "+ a + ", b = "+ b);
        scanner.close();
    }
}
